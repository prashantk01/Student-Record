package com.example.prince.studentrecord;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Spinner;

public class EditorActivity extends AppCompatActivity {
    private EditText mNameEditText;
    private Spinner mGenderSpinner;
    private EditText mFacultyEditText;
    private EditText mBranchEditText;
    private int mGender = DataContracter.DataEntry.GENDER_UNKNOWN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        // Find all relevant views that we will need to read user input from
        mNameEditText = (EditText) findViewById(R.id.edit_student_name);
        mGenderSpinner = (Spinner) findViewById(R.id.spinner_gender);
        mFacultyEditText = (EditText) findViewById(R.id.edit_student_facultyNo);
        mBranchEditText = (EditText) findViewById(R.id.edit_student_branch);


    }
}
